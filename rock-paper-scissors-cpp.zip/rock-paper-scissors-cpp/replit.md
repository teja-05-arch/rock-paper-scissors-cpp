# Rock Paper Scissors C++ Game

## Overview
A simple console-based Rock Paper Scissors game written in C++.

## Project Structure
- `Rock paper sissors.cpp` - Main game source file

## Build & Run
The project uses Clang++ compiler. The workflow compiles and runs the game:
```bash
clang++ -o game "Rock paper sissors.cpp" && ./game
```

## How to Play
1. Enter your move: R (Rock), P (Paper), or S (Scissors)
2. See the result against the computer
3. Choose to play again or quit

## Recent Changes
- January 31, 2026: Initial setup in Replit environment with C++ toolchain
