const express = require('express');
const path = require('path');
const app = express();
const port = 5000;

app.use(express.json());
app.use(express.static('public'));

// Trust proxy for Replit environment
app.set('trust proxy', true);

const moves = {
    'r': 'Rock',
    'p': 'Paper',
    's': 'Scissors'
};

function getComputerMove() {
    const moveKeys = Object.keys(moves);
    return moveKeys[Math.floor(Math.random() * moveKeys.length)];
}

function getResult(player, computer) {
    if (player === computer) return 0;
    if (
        (player === 'r' && computer === 's') ||
        (player === 'p' && computer === 'r') ||
        (player === 's' && computer === 'p')
    ) return 1;
    return -1;
}

app.post('/api/play', (req, res) => {
    const playerMove = req.body.move;
    const computerMove = getComputerMove();
    const result = getResult(playerMove, computerMove);

    let resultMessage = '';
    let resultClass = '';

    if (result === 0) {
        resultMessage = 'It\'s a Draw!';
        resultClass = 'draw';
    } else if (result === 1) {
        resultMessage = 'You Win!';
        resultClass = 'win';
    } else {
        resultMessage = 'Computer Wins!';
        resultClass = 'loss';
    }

    res.json({
        playerMoveName: moves[playerMove],
        computerMoveName: moves[computerMove],
        resultMessage,
        resultClass
    });
});

app.listen(port, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${port}`);
});
